function tocaSomClap(idElementoAudio) {
    document.querySelector(idElementoAudio).play();
}

const lista De Teclas = doucoment.querySelectorAll('.tecla');

//para
for (let contador = 0; contador <listeDe Teclas.length; contador++) {

    const tecla = listaDe Teclas[contador];
    const instrumento = tecla.classList[1];
    const idAudio = `#som_${instrumento}`; //template string

tecla.onclick = function (){
tocaSomClap(idAudio);
}

}